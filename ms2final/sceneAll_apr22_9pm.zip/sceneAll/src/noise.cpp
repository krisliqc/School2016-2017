//
//  noise.cpp
//  sceneAll
//
//  Created by Kris Li on 4/22/17.
//
//

#include "noise.hpp"

noise::noise(){
    
}

void noise::setup(){
    ofSetFrameRate(60);
    ofSetVerticalSync(true); // don't go too fast
    ofEnableAlphaBlending();
    
//        cloud.setMode(OF_PRIMITIVE_LINE_LOOP);
    
    // randomly allocate the points across the screen
    points.resize(nPoints);
    for(int i = 0; i < nPoints; i++) {
        points[i] = ofVec2f(ofRandom(0, ofGetWidth()), ofRandom(0, ofGetHeight()));
    }
    
    // we'll be drawing the points into an ofMesh that is drawn as bunch of points
    cloud.clear();
    cloud.setMode(OF_PRIMITIVE_POINTS);
}
