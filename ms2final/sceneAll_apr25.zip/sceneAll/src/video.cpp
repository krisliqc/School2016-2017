//
//  video.cpp
//  sceneAll
//
//  Created by Kris Li on 4/26/17.
//
//

#include "video.hpp"

//--------------------------------------------------------------
void video::setup(){
//    ofBackground(255,255,255);
    ofSetVerticalSync(true);
    frameByframe = false;
    
    // Uncomment this to show movies with alpha channels
    movie.setPixelFormat(OF_PIXELS_RGBA);
    
    movie.load("trace2.mov");
    movie.setLoopState(OF_LOOP_NORMAL);
    movie.play();
    
     pixels = movie.getPixels();
    
    vidWidth = pixels.getWidth();
    vidHeight = pixels.getHeight();
    nChannels = pixels.getNumChannels();
    
    for(int i = 0; i < pixels.size(); i++){
        float temp = 0.0;
        size.push_back(temp);
    }
    count = 0;
}

//--------------------------------------------------------------
void video::update(){
    movie.update();
}

//--------------------------------------------------------------
void video::draw(int _x, int _y, float _ratio){
    
//    ofSetHexColor(0xFFFFFF);
    
//    movie.draw(20,20);
//    ofSetHexColor(0x000000);
    
    pixels = movie.getPixels();
    
    // let's move through the "RGB(A)" char array
    // using the red pixel to control the size of a circle.
    for (int i = 4; i < vidWidth; i+=8){
        for (int j = 4; j < vidHeight; j+=8){
            
            unsigned char r = pixels[(j * 652 + i)*nChannels];
            unsigned char b = pixels[(j * 652 + i)*nChannels+2];
            
            float val = 1 - ((float)r / 255.0f);
            
//            ofPushStyle();
            ofSetColor(255,150);
            
            if(val < 0.5){
                continue;
//            cout << (float)r <<endl;
            }
            
            ofDrawCircle(i*_ratio + _x,j*_ratio + _y,10*val);
            ofDrawCircle(i*_ratio + _x,j*_ratio + _y,size[count]*5);
            
            size[count] = val;
            
//            ofPopStyle();
        }
        
        count ++;
        
        if(count > pixels.size()){
            count = 0;
        }
        ofSetColor(255);
    }
    

}





